#include <Arduino.h>
// Basic demo for accelerometer readings from Adafruit MPU6050

/** Sample Orientation Program with calibration.
 * NOTE/BUG: the decimal value is getting trimmed somewhere.
 *  -Dylan
 * 
 * Other 'main copy.txt' was the original test program that
 * just recorded angular velocity, not position.
 */

#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>
#include <Wire.h>

Adafruit_MPU6050 mpu;

const int MPU_addr = 0x68;
int16_t AcX, AcY, AcZ, Tmp, GyX, GyY, GyZ;

int minVal = 265;
int maxVal = 402;

double x;
double y;
double z;
double baseX;
double baseY;
double baseZ;


void setup()
{
  Wire.begin();
  Wire.beginTransmission(MPU_addr);
  Wire.write(0x6B);
  Wire.write(0);
  Wire.endTransmission(true);
  Serial.begin(9600);

  Wire.beginTransmission(MPU_addr);
  Wire.write(0x3B);
  Wire.endTransmission(false);
  Wire.requestFrom(MPU_addr, 14, true);
  AcX = Wire.read() << 8 | Wire.read();
  AcY = Wire.read() << 8 | Wire.read();
  AcZ = Wire.read() << 8 | Wire.read();
  int xAng = map(AcX, minVal, maxVal, -90, 90);
  int yAng = map(AcY, minVal, maxVal, -90, 90);
  int zAng = map(AcZ, minVal, maxVal, -90, 90);
  baseX = RAD_TO_DEG * (atan2(-yAng, -zAng) + PI);
  baseY = RAD_TO_DEG * (atan2(-xAng, -zAng) + PI);
  baseZ = RAD_TO_DEG * (atan2(-yAng, -xAng) + PI);
}
int angy(double baseAng, double ang) {
  double z = (baseAng - ang);
  if (z>359) z = z-360;
  return z;
}
void loop()
{
  Wire.beginTransmission(MPU_addr);
  Wire.write(0x3B);
  Wire.endTransmission(false);
  Wire.requestFrom(MPU_addr, 14, true);
  AcX = Wire.read() << 8 | Wire.read();
  AcY = Wire.read() << 8 | Wire.read();
  AcZ = Wire.read() << 8 | Wire.read();
  int xAng = map(AcX, minVal, maxVal, -90, 90);
  int yAng = map(AcY, minVal, maxVal, -90, 90);
  int zAng = map(AcZ, minVal, maxVal, -90, 90);

  x = RAD_TO_DEG * (atan2(-yAng, -zAng) + PI);
  y = RAD_TO_DEG * (atan2(-xAng, -zAng) + PI);
  z = RAD_TO_DEG * (atan2(-yAng, -xAng) + PI);

  Serial.print("AngleX= ");
  Serial.println(angy(baseX,x));

  Serial.print("AngleY= ");
  Serial.println(angy(baseY,y));

  Serial.print("AngleZ= ");
  Serial.println(angy(baseZ,z));

  Serial.println("-----------------------------------------");
  delay(1500);
}